var searchData=
[
  ['objetivos_20de_20aprendizaje_0',['Objetivos de Aprendizaje',['../index.html#objectives_sec',1,'']]]
];
