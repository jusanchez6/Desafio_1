var searchData=
[
  ['aprendizaje_0',['Objetivos de Aprendizaje',['../index.html#objectives_sec',1,'']]],
  ['autores_1',['Información de los Autores',['../index.html#author_sec',1,'']]]
];
