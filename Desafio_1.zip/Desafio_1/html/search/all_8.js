var searchData=
[
  ['los_20autores_0',['Información de los Autores',['../index.html#author_sec',1,'']]],
  ['lz78_5fdecompress_1',['lz78_decompress',['../compress_8hpp.html#ab55e7d720dfe6f22a4ef9d801e604af0',1,'lz78_decompress(const uint8_t *in, size_t len):&#160;compress.cpp'],['../compress_8cpp.html#ab55e7d720dfe6f22a4ef9d801e604af0',1,'lz78_decompress(const uint8_t *in, size_t len):&#160;compress.cpp']]]
];
