var searchData=
[
  ['objetivos_20de_20aprendizaje_0',['Objetivos de Aprendizaje',['../index.html#objectives_sec',1,'']]],
  ['ok_1',['OK',['../app_8hpp.html#adc5b9a540912c98e2af5a4933adefca0a2bc49ec37d6a5715dd23e85f1ff5bb59',1,'app.hpp']]]
];
