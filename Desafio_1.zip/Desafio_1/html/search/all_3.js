var searchData=
[
  ['de_20aprendizaje_0',['Objetivos de Aprendizaje',['../index.html#objectives_sec',1,'']]],
  ['de_20los_20autores_1',['Información de los Autores',['../index.html#author_sec',1,'']]],
  ['decodificación_2',['Documentación - Desafío 1: Compresión y Decodificación',['../index.html',1,'']]],
  ['del_20programa_3',['Detalles del Programa',['../index.html#details_sec',1,'']]],
  ['desafío_201_3a_20compresión_20y_20decodificación_4',['Documentación - Desafío 1: Compresión y Decodificación',['../index.html',1,'']]],
  ['detalles_20del_20programa_5',['Detalles del Programa',['../index.html#details_sec',1,'']]],
  ['documentación_20desafío_201_3a_20compresión_20y_20decodificación_6',['Documentación - Desafío 1: Compresión y Decodificación',['../index.html',1,'']]]
];
