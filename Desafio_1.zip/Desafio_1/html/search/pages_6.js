var searchData=
[
  ['metodología_0',['Metodología',['../index.html#methodology_sec',1,'']]]
];
