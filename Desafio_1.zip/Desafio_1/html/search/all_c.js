var searchData=
[
  ['programa_0',['Detalles del Programa',['../index.html#details_sec',1,'']]]
];
