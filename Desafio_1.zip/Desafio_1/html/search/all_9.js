var searchData=
[
  ['main_0',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['main_2ecpp_1',['main.cpp',['../main_8cpp.html',1,'']]],
  ['metodología_2',['Metodología',['../index.html#methodology_sec',1,'']]],
  ['my_5ferror_5ft_3',['my_error_t',['../app_8hpp.html#adc5b9a540912c98e2af5a4933adefca0',1,'app.hpp']]]
];
